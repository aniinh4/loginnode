-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 18-Out-2023 às 20:58
-- Versão do servidor: 10.4.27-MariaDB
-- versão do PHP: 8.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `loginapp`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL,
  `username` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `users`
--

INSERT INTO `users` (`id`, `username`, `password`) VALUES
(62, 'teste', '2e6f9b0d5885b6010f9167787445617f553a735f'),
(63, 'marcio', '46723173805278925281add7572c04a5dd841668'),
(64, 'milena', '7110eda4d09e062aa5e4a390b0a572ac0d2c0220'),
(65, 'veiga', '40bd001563085fc35165329ea1ff5c5ecbdbbeef'),
(66, 'isabila', '3da541559918a808c2402bba5012f6c60b27661c'),
(67, 'nini', '40bd001563085fc35165329ea1ff5c5ecbdbbeef'),
(68, 'kamile', '40bd001563085fc35165329ea1ff5c5ecbdbbeef'),
(69, 'caroline', '7110eda4d09e062aa5e4a390b0a572ac0d2c0220'),
(70, 'aluno', '23a6a3cf06cfd8b1a6cda468e5756a6a6a1d21e7'),
(71, 'senai', '7110eda4d09e062aa5e4a390b0a572ac0d2c0220'),
(72, 'SENAI', '1234'),
(73, 'ee', '1f444844b1ca616009c2b0e3564fecc065872b5b'),
(74, 'SENAI', '7110eda4d09e062aa5e4a390b0a572ac0d2c0220');

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=75;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
